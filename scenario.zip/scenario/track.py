# import cv2
# import numpy as np
# from ultralytics import YOLO
# from collections import deque
# import os
# import time

# def run(args):
#     # Khởi tạo mô hình
#     model = YOLO(args['yolo_model'])
    
#     # 0. ĐỌC THÔNG SỐ VIDEO GỐC
#     cap_temp = cv2.VideoCapture(str(args['source']))
#     FPS_VIDEO = cap_temp.get(cv2.CAP_PROP_FPS)
#     W_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_WIDTH))
#     H_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
#     if FPS_VIDEO == 0 or np.isnan(FPS_VIDEO): 
#         FPS_VIDEO = 30 
#     cap_temp.release()

#     # Thư mục lưu ảnh vi phạm
#     violation_dir = "temp_results/violations"
#     os.makedirs(violation_dir, exist_ok=True)

#     # Bộ ghi video
#     out_video_path = args.get('output_path', 'temp_results/default_output.mp4')
#     fourcc = cv2.VideoWriter_fourcc(*'mp4v')
#     out_video = cv2.VideoWriter(out_video_path, fourcc, FPS_VIDEO, (W_VIDEO, H_VIDEO))

#     # 1. CẤU HÌNH MA TRẬN (Homography)
#     pts_src = np.array(args['points'], dtype=np.float32)
#     W_m, L_m = float(args['width_m']), float(args['length_m'])
#     limit = float(args.get('speed_limit', 60))
    
#     # Đích: Hình chữ nhật nhìn từ trên xuống
#     pts_dst = np.array([[0, L_m], [W_m, L_m], [W_m, 0], [0, 0]], dtype=np.float32)
#     homography_matrix = cv2.getPerspectiveTransform(pts_src, pts_dst)

#     # 2. BỘ LỌC LÀM MƯỢT
#     track_history = {} 
#     saved_violations = set() # Lưu các ID đã chụp ảnh rồi
    
#     if not hasattr(run, 'speed_state'):
#         run.speed_state = {
#             'raw_speed_history': {},
#             'moving_average_speeds': {},
#             'final_exported_speeds': {}
#         }
#     state = run.speed_state

#     # 3. CHẠY TRACKING (Tối ưu cho CPU)
#     results = model.track(
#         source=str(args['source']),
#         conf=args['conf'],
#         iou=args.get('iou', 0.5),
#         imgsz=320,      # 🟢 GIẢM: Giúp CPU máy cũ chạy nhanh hơn
#         half=False,     # 🟢 TẮT: CPU không hỗ trợ FP16
#         device='cpu',   # 🟢 ÉP: Luôn chạy bằng CPU
#         show=False,
#         save=False, 
#         tracker=f"{args['tracking_method']}.yaml", 
#         classes=args['classes'],
#         persist=True,
#         stream=True
#     )

#     for frame_idx, r in enumerate(results):
#         annotated_frame = r.plot()
#         orig_img = r.orig_img.copy() # Lưu ảnh gốc sạch để cắt ảnh vi phạm
        
#         # Vẽ ROI
#         cv2.polylines(annotated_frame, [pts_src.astype(np.int32)], True, (255, 0, 255), 3)

#         if r.boxes is not None and r.boxes.id is not None:
#             boxes = r.boxes.xyxy.cpu().numpy()
#             ids = r.boxes.id.cpu().numpy().astype(int)

#             for box, obj_id in zip(boxes, ids):
#                 x1, y1, x2, y2 = box
#                 cx, bottom_y = (x1 + x2) / 2, y2 

#                 # TỌA ĐỘ THỰC
#                 pt_pixel = np.array([[[cx, bottom_y]]], dtype=np.float32)
#                 pt_real = cv2.perspectiveTransform(pt_pixel, homography_matrix)[0][0]
#                 X_m, Y_m = pt_real[0], pt_real[1] 

#                 if obj_id not in track_history:
#                     track_history[obj_id] = deque(maxlen=15)
#                     state['raw_speed_history'][obj_id] = deque(maxlen=15)
#                     state['moving_average_speeds'][obj_id] = deque(maxlen=5)

#                 track_history[obj_id].append((frame_idx, X_m, Y_m))

#                 # TÍNH VẬN TỐC
#                 if len(track_history[obj_id]) >= 15:
#                     old_f, old_X, old_Y = track_history[obj_id][0]
#                     dist = np.sqrt((X_m - old_X)**2 + (Y_m - old_Y)**2)
#                     dt = (frame_idx - old_f) / FPS_VIDEO
                    
#                     if dt > 0:
#                         v_raw = (dist / dt) * 3.6 
#                         state['raw_speed_history'][obj_id].append(v_raw)
                        
#                         v_avg = sum(state['raw_speed_history'][obj_id]) / len(state['raw_speed_history'][obj_id])
#                         state['moving_average_speeds'][obj_id].append(v_avg)
                        
#                         final_v = sum(state['moving_average_speeds'][obj_id]) / len(state['moving_average_speeds'][obj_id])
                        
#                         if 5 < final_v < 180:
#                             # 🟢 XỬ LÝ VI PHẠM
#                             is_speeding = final_v > limit
#                             color = (0, 0, 255) if is_speeding else (0, 255, 0)
                            
#                             # Hiển thị text
#                             cv2.putText(annotated_frame, f"{final_v:.1f} km/h", (int(x1), int(y1) - 10), 
#                                         cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 3)
                            
#                             # Chụp ảnh xe vi phạm (Chỉ chụp 1 lần/xe)
#                             if is_speeding and obj_id not in saved_violations:
#                                 # Cắt ảnh xe từ ảnh gốc sạch
#                                 # Đảm bảo tọa độ không vượt quá kích thước ảnh
#                                 crop_x1, crop_y1 = max(0, int(x1)), max(0, int(y1))
#                                 crop_x2, crop_y2 = min(W_VIDEO, int(x2)), min(H_VIDEO, int(y2))
                                
#                                 crop_img = orig_img[crop_y1:crop_y2, crop_x1:crop_x2]
                                
#                                 if crop_img.size > 0:
#                                     fname = f"xe_{obj_id}_{int(final_v)}kmh_{int(time.time())}.jpg"
#                                     cv2.imwrite(os.path.join(violation_dir, fname), crop_img)
#                                     saved_violations.add(obj_id)

#                             state['final_exported_speeds'][obj_id] = (final_v, "VI PHAM" if is_speeding else "OK")

#         out_video.write(annotated_frame)

#     out_video.release()
#     cv2.destroyAllWindows()
#     print(f"--- Hoàn tất! Đã lưu {len(saved_violations)} ảnh xe vi phạm. ---")

# def track(args):
#     run(args)


# import cv2
# import numpy as np
# from ultralytics import YOLO
# from collections import deque
# import os
# import time
# import requests

# def run(args):
#     model = YOLO(args['yolo_model'])
    
#     cap_temp = cv2.VideoCapture(str(args['source']))
#     FPS_VIDEO = cap_temp.get(cv2.CAP_PROP_FPS)
#     W_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_WIDTH))
#     H_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_HEIGHT))
#     if FPS_VIDEO == 0 or np.isnan(FPS_VIDEO): FPS_VIDEO = 30
#     cap_temp.release()

#     violation_dir = "temp_results/violations"
#     os.makedirs(violation_dir, exist_ok=True)

#     out_video_path = args.get('output_path', 'temp_results/default_output.mp4')
#     fourcc = cv2.VideoWriter_fourcc(*'mp4v')
#     out_video = cv2.VideoWriter(out_video_path, fourcc, FPS_VIDEO, (W_VIDEO, H_VIDEO))

#     pts_src = np.array(args['points'], dtype=np.float32)
#     W_m, L_m = float(args['width_m']), float(args['length_m'])
#     limit = float(args.get('speed_limit', 60))
#     pts_dst = np.array([[0, L_m], [W_m, L_m], [W_m, 0], [0, 0]], dtype=np.float32)
#     homography_matrix = cv2.getPerspectiveTransform(pts_src, pts_dst)

#     # Cấu hình bước nhảy để cứu CPU
#     STRIDE = 2
#     track_history = {}
#     saved_violations = set()
    
#     # Khởi tạo không gian lưu trữ lịch sử tốc độ để làm mịn thuật toán (Moving Average)
#     if not hasattr(run, 'speed_buffer'):
#         run.speed_buffer = {}
    
#     # AI Tracking
#     results = model.track(
#         source=str(args['source']),
#         conf=args['conf'],
#         imgsz=320,      # Tối ưu CPU
#         device='cpu',
#         tracker="bytetrack.yaml",
#         classes=args['classes'],
#         persist=True,
#         stream=True,
#         vid_stride=STRIDE
#     )

#     for i, r in enumerate(results):
#         real_frame_idx = i * STRIDE
#         annotated_frame = r.plot()
#         cv2.polylines(annotated_frame, [pts_src.astype(np.int32)], True, (255, 0, 255), 3)

#         if r.boxes is not None and r.boxes.id is not None:
#             boxes = r.boxes.xyxy.cpu().numpy()
#             ids = r.boxes.id.cpu().numpy().astype(int)

#             for box, obj_id in zip(boxes, ids):
#                 x1, y1, x2, y2 = box
#                 cx, bottom_y = (x1 + x2) / 2, y2

#                 pt_pixel = np.array([[[cx, bottom_y]]], dtype=np.float32)
#                 pt_real = cv2.perspectiveTransform(pt_pixel, homography_matrix)[0][0]
#                 X_m, Y_m = pt_real[0], pt_real[1]

#                 if obj_id not in track_history:
#                     # Mở rộng lịch sử lưu tọa độ lên 15 frame để đo quãng đường dài hơn
#                     track_history[obj_id] = deque(maxlen=15)
#                     # Tạo bộ nhớ đệm lưu 5 mức tốc độ gần nhất để tính trung bình
#                     run.speed_buffer[obj_id] = deque(maxlen=5)

#                 track_history[obj_id].append((real_frame_idx, X_m, Y_m))

#                 # Chỉ tính tốc độ khi xe đã di chuyển được ít nhất 10 frame trong vùng ROI
#                 if len(track_history[obj_id]) >= 10:
#                     old_f, old_X, old_Y = track_history[obj_id][0]
#                     dist = np.sqrt((X_m - old_X)**2 + (Y_m - old_Y)**2)
#                     dt = (real_frame_idx - old_f) / FPS_VIDEO
                    
#                     # Bắt buộc thời gian trôi qua phải lớn hơn 0.2 giây để tránh nhiễu do sai số 1-2 pixel
#                     if dt > 0.2:
#                         raw_speed = (dist / dt) * 3.6
                        
#                         # Chỉ chấp nhận các kết quả tốc độ nằm trong dải vật lý hợp lý
#                         if 5 < raw_speed < 180:
#                             run.speed_buffer[obj_id].append(raw_speed)
                            
#                             # Lấy trung bình cộng (Smoothing) các lần đo gần nhất
#                             smoothed_speed = sum(run.speed_buffer[obj_id]) / len(run.speed_buffer[obj_id])
                            
#                             is_speeding = smoothed_speed > limit
#                             color = (0, 0, 255) if is_speeding else (0, 255, 0)
#                             cv2.putText(annotated_frame, f"{smoothed_speed:.1f} km/h", (int(x1), int(y1) - 10),
#                                         cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
                            
#                             # --- XỬ LÝ CẮT ẢNH VÀ LƯU DATABASE ---
#                             if is_speeding and obj_id not in saved_violations:
#                                 padding = 30 # Mở rộng thêm 30 pixel mỗi bên
                                
#                                 # Tính toán tọa độ mới, dùng max/min để không bị cắt lố ra ngoài viền video
#                                 c_x1 = max(0, int(x1) - padding)
#                                 c_y1 = max(0, int(y1) - padding)
#                                 c_x2 = min(W_VIDEO, int(x2) + padding)
#                                 c_y2 = min(H_VIDEO, int(y2) + padding)
                                
#                                 crop = r.orig_img[c_y1:c_y2, c_x1:c_x2]
                                
#                                 if crop.size > 0:
#                                     # Sử dụng tốc độ đã làm mượt (smoothed_speed) để lưu tên file
#                                     violation_filename = f"xe_{obj_id}_{int(smoothed_speed)}kmh.jpg"
#                                     cv2.imwrite(f"{violation_dir}/{violation_filename}", crop)
#                                     saved_violations.add(obj_id)

#                                     # ---- ĐOẠN CODE KẾT NỐI SANG NODE.JS ----
#                                     try:
#                                         payload = {
#                                             "sessionId": int(args.get("session_id", 0)),
#                                             "trackId": int(obj_id),
#                                             "type": "vehicle", 
#                                             "speed": float(smoothed_speed), # Truyền tốc độ mượt sang CSDL
#                                             "path": f"http://localhost:8000/results/violations/{violation_filename}"
#                                         }
                                        
#                                         # Bắn dữ liệu sang cổng 5000 của Node.js
#                                         response = requests.post('http://localhost:5000/api/violations', json=payload, timeout=2)
                                        
#                                         if response.status_code == 201:
#                                             print(f"[SYNC] Đã đồng bộ vi phạm ID: {obj_id} (Vận tốc: {smoothed_speed:.1f} km/h) sang CSDL PostgreSQL.")
#                                     except Exception as e:
#                                         print(f"[ERROR] Mất kết nối tới Node.js Backend: {e}")

#         for _ in range(STRIDE): out_video.write(annotated_frame)

#     out_video.release()

# import cv2
# import numpy as np
# from ultralytics import YOLO
# import os
# import requests

# def run(args):
#     model = YOLO(args['yolo_model'])
    
#     cap_temp = cv2.VideoCapture(str(args['source']))
#     FPS_VIDEO = cap_temp.get(cv2.CAP_PROP_FPS)
#     W_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_WIDTH))
#     H_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_HEIGHT))
#     if FPS_VIDEO == 0 or np.isnan(FPS_VIDEO): FPS_VIDEO = 30
#     cap_temp.release()

#     violation_dir = "temp_results/violations"
#     os.makedirs(violation_dir, exist_ok=True)

#     out_video_path = args.get('output_path', 'temp_results/default_output.mp4')
#     fourcc = cv2.VideoWriter_fourcc(*'mp4v')
#     out_video = cv2.VideoWriter(out_video_path, fourcc, FPS_VIDEO, (W_VIDEO, H_VIDEO))

#     pts_src = np.array(args['points'], dtype=np.float32)
#     W_m, L_m = float(args['width_m']), float(args['length_m'])
#     limit = float(args.get('speed_limit', 60))
#     pts_dst = np.array([[0, L_m], [W_m, L_m], [W_m, 0], [0, 0]], dtype=np.float32)
#     homography_matrix = cv2.getPerspectiveTransform(pts_src, pts_dst)

#     STRIDE = 2
    
#     # --- THUẬT TOÁN BẪY TỐC ĐỘ (SPEED TRAP) ---
#     entry_data = {}       # Lưu tọa độ và thời gian LÚC MỚI VÀO vùng theo dõi
#     speed_decisions = {}  # Lưu kết quả chốt hạ (Chỉ tính 1 lần duy nhất)
    
#     results = model.track(
#         source=str(args['source']),
#         conf=args['conf'],
#         imgsz=320,
#         device='cpu',
#         tracker="bytetrack.yaml",
#         classes=args['classes'],
#         persist=True,
#         stream=True,
#         vid_stride=STRIDE
#     )

#     for i, r in enumerate(results):
#         real_frame_idx = i * STRIDE
#         annotated_frame = r.plot()
#         cv2.polylines(annotated_frame, [pts_src.astype(np.int32)], True, (255, 0, 255), 3)

#         if r.boxes is not None and r.boxes.id is not None:
#             boxes = r.boxes.xyxy.cpu().numpy()
#             ids = r.boxes.id.cpu().numpy().astype(int)

#             for box, obj_id in zip(boxes, ids):
#                 x1, y1, x2, y2 = box
#                 cx, bottom_y = (x1 + x2) / 2, y2

#                 pt_pixel = np.array([[[cx, bottom_y]]], dtype=np.float32)
#                 pt_real = cv2.perspectiveTransform(pt_pixel, homography_matrix)[0][0]
#                 X_m, Y_m = pt_real[0], pt_real[1]

#                 # Bước 1: Ghi nhận vị trí bắt đầu
#                 if obj_id not in entry_data:
#                     entry_data[obj_id] = (real_frame_idx, X_m, Y_m)

#                 # Bước 2: Chờ xe chạy đủ quãng đường quy định rồi chốt kết quả
#                 if obj_id not in speed_decisions:
#                     entry_f, entry_x, entry_y = entry_data[obj_id]
#                     dist = np.sqrt((X_m - entry_x)**2 + (Y_m - entry_y)**2)

#                     # KHOẢNG CÁCH BẪY: Yêu cầu xe phải chạy được đúng 15 mét thực tế
#                     if dist >= 15.0:
#                         dt = (real_frame_idx - entry_f) / FPS_VIDEO
#                         if dt > 0:
#                             # Tính vận tốc CHỐT HẠ
#                             final_speed = (dist / dt) * 3.6
                            
#                             # Lọc bỏ các giá trị nhiễu vô lý (dưới 5km/h hoặc trên 180km/h)
#                             if 5 < final_speed < 180:
#                                 speed_decisions[obj_id] = final_speed
                                
#                                 # === RA QUYẾT ĐỊNH VI PHẠM TẠI ĐÂY ===
#                                 if final_speed > limit:
#                                     padding = 30
#                                     c_x1 = max(0, int(x1) - padding)
#                                     c_y1 = max(0, int(y1) - padding)
#                                     c_x2 = min(W_VIDEO, int(x2) + padding)
#                                     c_y2 = min(H_VIDEO, int(y2) + padding)
#                                     crop = r.orig_img[c_y1:c_y2, c_x1:c_x2]
                                    
#                                     if crop.size > 0:
#                                         violation_filename = f"xe_{obj_id}_{int(final_speed)}kmh.jpg"
#                                         cv2.imwrite(f"{violation_dir}/{violation_filename}", crop)

#                                         # Đồng bộ Node.js
#                                         try:
#                                             payload = {
#                                                 "sessionId": int(args.get("session_id", 0)),
#                                                 "trackId": int(obj_id),
#                                                 "type": "vehicle", 
#                                                 "speed": float(final_speed),
#                                                 "path": f"http://localhost:8000/results/violations/{violation_filename}"
#                                             }
#                                             response = requests.post('http://localhost:5000/api/violations', json=payload, timeout=2)
#                                             if response.status_code == 201:
#                                                 print(f"[SYNC] Đã bắt vi phạm ID {obj_id} với tốc độ chốt hạ {final_speed:.1f} km/h")
#                                         except Exception as e:
#                                             pass
                
#                 # Bước 3: Hiển thị lên màn hình
#                 if obj_id in speed_decisions:
#                     # Xe đã qua bẫy: In tốc độ chốt hạ (số không bao giờ nhảy nữa)
#                     final_v = speed_decisions[obj_id]
#                     color = (0, 0, 255) if final_v > limit else (0, 255, 0)
#                     cv2.putText(annotated_frame, f"{final_v:.1f} km/h", (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
#                 else:
#                     # Xe đang nằm trong đoạn bẫy 15 mét đầu tiên: Hiện chữ Measuring...
#                     cv2.putText(annotated_frame, "Measuring...", (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

#         for _ in range(STRIDE): out_video.write(annotated_frame)

#     out_video.release()

import cv2
import numpy as np
from ultralytics import YOLO
import os
import requests

def run(args):
    model = YOLO(args['yolo_model'])
    
    cap_temp = cv2.VideoCapture(str(args['source']))
    FPS_VIDEO = cap_temp.get(cv2.CAP_PROP_FPS)
    W_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_WIDTH))
    H_VIDEO = int(cap_temp.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if FPS_VIDEO == 0 or np.isnan(FPS_VIDEO): FPS_VIDEO = 30
    cap_temp.release()

    violation_dir = "temp_results/violations"
    os.makedirs(violation_dir, exist_ok=True)

    out_video_path = args.get('output_path', 'temp_results/default_output.mp4')
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_video = cv2.VideoWriter(out_video_path, fourcc, FPS_VIDEO, (W_VIDEO, H_VIDEO))

    pts_src = np.array(args['points'], dtype=np.float32)
    W_m, L_m = float(args['width_m']), float(args['length_m'])
    limit = float(args.get('speed_limit', 60))
    pts_dst = np.array([[0, L_m], [W_m, L_m], [W_m, 0], [0, 0]], dtype=np.float32)
    homography_matrix = cv2.getPerspectiveTransform(pts_src, pts_dst)

    STRIDE = 2
    
    # --- THUẬT TOÁN BẪY TỐC ĐỘ (SPEED TRAP) ---
    entry_data = {}       # Lưu tọa độ và thời gian LÚC MỚI VÀO vùng theo dõi
    speed_decisions = {}  # Lưu kết quả chốt hạ (Chỉ tính 1 lần duy nhất)
    
    results = model.track(
        source=str(args['source']),
        conf=args['conf'],
        imgsz=320,
        device='cpu',
        tracker="bytetrack.yaml",
        classes=args['classes'],
        persist=True,
        stream=True,
        vid_stride=STRIDE
    )

    for i, r in enumerate(results):
        real_frame_idx = i * STRIDE
        annotated_frame = r.plot()
        cv2.polylines(annotated_frame, [pts_src.astype(np.int32)], True, (255, 0, 255), 3)

        if r.boxes is not None and r.boxes.id is not None:
            boxes = r.boxes.xyxy.cpu().numpy()
            ids = r.boxes.id.cpu().numpy().astype(int)

            for box, obj_id in zip(boxes, ids):
                x1, y1, x2, y2 = box
                cx, bottom_y = (x1 + x2) / 2, y2

                pt_pixel = np.array([[[cx, bottom_y]]], dtype=np.float32)
                pt_real = cv2.perspectiveTransform(pt_pixel, homography_matrix)[0][0]
                X_m, Y_m = pt_real[0], pt_real[1]

                # Bước 1: Ghi nhận vị trí bắt đầu
                if obj_id not in entry_data:
                    entry_data[obj_id] = (real_frame_idx, X_m, Y_m)

                # Bước 2: Chờ xe chạy đủ quãng đường quy định rồi chốt kết quả
                if obj_id not in speed_decisions:
                    entry_f, entry_x, entry_y = entry_data[obj_id]
                    dist = np.sqrt((X_m - entry_x)**2 + (Y_m - entry_y)**2)

                    # KHOẢNG CÁCH BẪY: Yêu cầu xe phải chạy được đúng 15 mét thực tế
                    if dist >= 15.0:
                        dt = (real_frame_idx - entry_f) / FPS_VIDEO
                        if dt > 0:
                            # Tính vận tốc CHỐT HẠ
                            final_speed = (dist / dt) * 3.6
                            
                            # Lọc bỏ các giá trị nhiễu vô lý (dưới 5km/h hoặc trên 180km/h)
                            if 5 < final_speed < 180:
                                speed_decisions[obj_id] = final_speed
                                
                                # === RA QUYẾT ĐỊNH VI PHẠM TẠI ĐÂY ===
                                if final_speed > limit:
                                    padding = 30
                                    c_x1 = max(0, int(x1) - padding)
                                    c_y1 = max(0, int(y1) - padding)
                                    c_x2 = min(W_VIDEO, int(x2) + padding)
                                    c_y2 = min(H_VIDEO, int(y2) + padding)
                                    crop = r.orig_img[c_y1:c_y2, c_x1:c_x2]
                                    
                                    if crop.size > 0:
                                        violation_filename = f"xe_{obj_id}_{int(final_speed)}kmh.jpg"
                                        cv2.imwrite(f"{violation_dir}/{violation_filename}", crop)

                                        # Đồng bộ Node.js
                                        try:
                                            payload = {
                                                "sessionId": int(args.get("session_id", 0)),
                                                "trackId": int(obj_id),
                                                "type": "vehicle", 
                                                "speed": float(final_speed),
                                                "path": f"http://localhost:8000/results/violations/{violation_filename}"
                                            }
                                            response = requests.post('http://localhost:5000/api/violations', json=payload, timeout=2)
                                            if response.status_code == 201:
                                                print(f"[SYNC] Đã bắt vi phạm ID {obj_id} với tốc độ chốt hạ {final_speed:.1f} km/h")
                                        except Exception as e:
                                            pass
                
                # Bước 3: Hiển thị lên màn hình
                if obj_id in speed_decisions:
                    # Xe đã qua bẫy: In tốc độ chốt hạ (số không bao giờ nhảy nữa)
                    final_v = speed_decisions[obj_id]
                    color = (0, 0, 255) if final_v > limit else (0, 255, 0)
                    cv2.putText(annotated_frame, f"{final_v:.1f} km/h", (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
                else:
                    # Xe đang nằm trong đoạn bẫy 15 mét đầu tiên: Hiện chữ Measuring...
                    cv2.putText(annotated_frame, "Measuring...", (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

        for _ in range(STRIDE): out_video.write(annotated_frame)

    out_video.release()